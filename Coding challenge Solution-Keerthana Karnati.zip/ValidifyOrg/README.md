org details:
username:keerthana.karnati2@validify.challenge
emailid:karnatikeerthana22@gmail.com
pasword:Salesforce@111
profile:system administrator

RESTPOINT:
GET-To provide the ID to fetch the particular record
HTTPOST-To provide the JSONpayload data 

The authentication information:
Connected app name -NodeJSInt

Callback URL	
https://your-nodejs-app.com/oauth/callback

Consumer Key	
3MVG9WVXk15qiz1JyKlc_RN3St7JRxcaFLI6Iq2LdW3uu6OXBZ5ywD7E54NmW1YxYRN86H_mNIG.2FYgAPm31
Consumer Secret	
1ED9B7E7DEC60BC54BD9F52846327B551643EE4576BC509701136E2DB434464E

Selected OAuth Scopes:	
Manage user data via APIs (api)
Manage user data via Web browsers (web)
Full access (full)
Access Connect REST API resources (chatter_api)
Access unique user identifiers (openid)

Implementation overview:
1.Created a connected app.
2.Created a single custom object companyData__c with the required custom fields to fetch the data of customers,payments,referrals and other datasubsets to support a scalable integration connection.
3.Created recordtypes and pagelayouts for customer,payments,referral inorder to differentiate the customer,payment,referral records and 
4.Created an apex REST service class to handle inbound requests for HTTPGET and HTTPOST methods and created a wrapper class to processes the incoming bulk data loads and for future scope.
5.Assigned the record to related recordtype to have a structered data
6.Tested the request and response with POSTMAN(GET,POST) for multiple JSON payloads.
